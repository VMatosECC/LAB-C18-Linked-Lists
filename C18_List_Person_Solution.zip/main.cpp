//============================================================
// main.cpp
// CS2 Lab C17 — list<Person> Linked List Database
//
// Author : V. Matos  —  El Camino College
//============================================================
#include <iostream>
#include <list>
#include <limits>
#include <stdexcept>
#include "Person.h"
using namespace std;

//------------------------------------------------------------
// printList — helper to print the full list with a label
//------------------------------------------------------------
void printList(const list<Person>& db, const string& label = "") {
    if (!label.empty())
        cout << "\n" << label << " (size=" << db.size() << "):\n";
    for (const auto& p : db)
        cout << "  " << p << "\n";
}

//------------------------------------------------------------
// buildDatabase — interactive input loop
//------------------------------------------------------------
void buildDatabase(list<Person>& db) {
    cout << "\n=== Person Database  list<Person> ===\n";
    char   again = 'y';
    string name;
    int    age;

    while (tolower(again) == 'y') {
        cout << "\nEnter name: ";
        getline(cin, name);

        cout << "Enter age:  ";
        cin  >> age;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        try {
            db.push_back(Person(name, age));
            cout << "  Added: " << db.back() << "\n";
        }
        catch (const runtime_error& e) {
            cout << "  REJECTED: " << e.what() << "\n";
        }

        cout << "Add another? [y/n]: ";
        cin  >> again;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

//------------------------------------------------------------
// demonstrateListOps — push_front, pop_front, pop_back
//------------------------------------------------------------
void demonstrateListOps(list<Person>& db) {
    cout << "\n--- Part 3: List-Specific Operations ---\n";

    // push_front() — add to the FRONT in O(1)
    db.push_front(Person("Montgomery Burns", 104));
    printList(db, "After push_front(Montgomery Burns)");

    // pop_front() — save front() BEFORE calling pop (returns void!)
    Person removed_front = db.front();
    db.pop_front();
    cout << "\npop_front() removed: " << removed_front << "\n";
    printList(db, "After pop_front()");

    // pop_back() — save back() BEFORE calling pop (returns void!)
    Person removed_back = db.back();
    db.pop_back();
    cout << "\npop_back() removed: " << removed_back << "\n";
    printList(db, "After pop_back()");
}

//------------------------------------------------------------
// main
//------------------------------------------------------------
int main() {
    list<Person> db;

    // Part 2 — interactive input
    buildDatabase(db);

    // Print the complete database
    printList(db, "--- Database after input ---");

    // Part 3 — list-specific operations
    if (db.empty()) {
        cout << "\nList is empty — add at least one person to see list operations.\n";
    } else {
        demonstrateListOps(db);
    }

    cout << "\nAll done!\n";
    return 0;
}