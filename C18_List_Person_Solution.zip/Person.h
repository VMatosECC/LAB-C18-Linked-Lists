//============================================================
// Person.h
// CS2 Lab C17 — list<Person> Linked List Database
//
// Author : V. Matos  —  El Camino College
//============================================================
#pragma once
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
using namespace std;

class Person {
private:
    string name;
    int    age;

public:
    //----------------------------------------------------------
    // Setters with validation
    //----------------------------------------------------------
    void setName(const string& nameValue) {
        if (nameValue.empty())
            throw runtime_error("Name cannot be empty.");
        name = nameValue;
    }

    void setAge(int ageValue) {
        if (ageValue < 0 || ageValue > 120)
            throw runtime_error(
                "Age out of range: " + to_string(ageValue)
                + ". Valid range: [0, 120].");
        age = ageValue;
    }

    //----------------------------------------------------------
    // Getters
    //----------------------------------------------------------
    string getName() const { return name; }
    int    getAge()  const { return age;  }

    //----------------------------------------------------------
    // Constructor — calls setters so bad args throw immediately
    //----------------------------------------------------------
    Person(string n = "n.a", int a = 0) {
        setName(n);
        setAge(a);
    }

    //----------------------------------------------------------
    // toString() — virtual for future inheritance
    //----------------------------------------------------------
    virtual string toString() const {
        ostringstream sout;
        sout << this << " Person [Name: " << name
            << ", Age: " << age << "]";
        return sout.str();
    }

    //----------------------------------------------------------
    // operator<< — delegates to virtual toString()
    //----------------------------------------------------------
    friend ostream& operator<<(ostream& sout, const Person& p) {
        sout << p.toString();
        return sout;
    }
};