// People-Database-STARTER.cpp
// CS2 Lab — Memory-Resident Database
// Student Name: ______________________________  Date: ________________
//
// Dataset: https://github.com/VMatosECC/Datasets/tree/main/Simpsons
// Download springfieldpeople.txt ==> c:/temp/springfieldpeople.txt

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <list>
#include <map>
#include <algorithm>    // find_if
#include "Person.h"
using namespace std;

// Shorthand type aliases -------------------------------------------------------
typedef map<string, list<Person>::iterator>      DBmap;
typedef multimap<string, list<Person>::iterator> DBmmap;

// Utility functions ------------------------------------------------------------
template <class T>
void showList(const list<T>& lst, string caption = "") {
    cout << endl << caption << "  Size: " << lst.size() << endl;
    cout << string(50, '-') << endl;
    for (const auto& node : lst)
        cout << node << endl;
    cout << string(50, '-') << endl;
}

void showIndices(const DBmap& idMap,
                 const DBmap& nameMap,
                 const DBmmap& ageMultimap) {
    cout << "\nidMap (ID key → record)\n";
    for (const auto& row : idMap)
        cout << "  " << row.first << "\t" << *row.second << endl;

    cout << "\nnameMap (NAME key → record)\n";
    for (const auto& row : nameMap)
        cout << "  " << row.first << "\t" << *row.second << endl;

    cout << "\nageMultimap (AGE key → record(s))\n";
    for (const auto& row : ageMultimap)
        cout << "  " << row.first << "\t" << *row.second << endl;
}

// Load -------------------------------------------------------------------------
void loadDatabase(list<Person>& db,
                  DBmap& idMap, DBmap& nameMap, DBmmap& ageMultimap) {
    ifstream infile("c:/temp/springfieldpeople.txt");
    if (!infile) { cout << "Fatal error - file not found\n"; exit(101); }

    Person p;
    while (getline(infile, p.id,   ',') &&
           getline(infile, p.name, ',') &&
           getline(infile, p.age,  ',') &&
           getline(infile, p.info)) {
        db.push_back(p);
        idMap[p.id]   = prev(db.end());
        nameMap[p.name] = prev(db.end());
        ageMultimap.emplace(p.age, prev(db.end()));
    }
    infile.close();
}

// Search functions -------------------------------------------------------------
void exactSearch(const DBmap& m, string keyName = "") {
    string key;
    cout << "\n=== Exact search by " << keyName << " ===\n";
    do {
        cout << "(" << keyName << ") Enter search key [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto itm = m.find(key);
        if (itm == m.end())
            cout << "  Not found: \"" << key << "\"\n";
        else
            cout << "  Found ==> " << *itm->second << "\n";
    } while (true);
}

void multiSearch(const DBmmap& mm, string keyName = "") {
    string key;
    cout << "\n=== Exact search by " << keyName << " (multimap) ===\n";
    do {
        cout << "(" << keyName << ") Enter search key [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto range = mm.equal_range(key);
        if (range.first == range.second)
            cout << "  No records with " << keyName << " = " << key << "\n";
        else
            for (auto it = range.first; it != range.second; ++it)
                cout << "  Found ==> " << *it->second << "\n";
    } while (true);
}

void partialMatch(const DBmap& m, string keyName = "") {
    string key;
    cout << "\n=== Prefix search by " << keyName << " ===\n";
    do {
        cout << "(" << keyName << ") Enter prefix [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto it = m.lower_bound(key);
        bool found = false;
        while (it != m.end() && it->first.compare(0, key.size(), key) == 0) {
            cout << "  Found ==> " << *it->second << "\n";
            ++it;
            found = true;
        }
        if (!found) cout << "  No records with prefix \"" << key << "\"\n";
    } while (true);
}

// TODO Part 4 Challenge --------------------------------------------------------
// Implement partialMatchMulti() — prefix search on the age multimap.
// Entering prefix "4" should return everyone whose age starts with 4
// (40, 41, 42, 43, …).
//
void partialMatchMulti(const DBmmap& mm, string keyName = "") {
    string prefix;
    cout << "\n=== Prefix search by " << keyName << " (multimap) ===\n";
    do {
        cout << "(" << keyName << ") Enter prefix [q to end]: ";
        getline(cin, prefix);
        if (prefix == "q") break;

        // TODO: use lower_bound + compare loop on the multimap
        // Hint: identical logic to partialMatch — lower_bound and compare
        //       work the same way on std::multimap.

    } while (true);
}

// Experiments ------------------------------------------------------------------
void experiment01() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database");
    showIndices(idMap, nameMap, ageMultimap);

    exactSearch(idMap,       "ID");
    exactSearch(nameMap,     "NAME");
    multiSearch(ageMultimap, "AGE");
    partialMatch(nameMap,    "NAME PREFIX");
    partialMatchMulti(ageMultimap, "AGE PREFIX");  // Part 4 challenge
}

void experiment02() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database (Before insert)");

    // --- Insert ---
    Person newPerson("200", "Otto Mann", "45", "data200");
    cout << "\nAdding ==> " << newPerson << endl;

    if (idMap.count("200") == 1)
        throw runtime_error("Insert ignored - similar key already exists");

    db.push_back(newPerson);
    idMap[newPerson.id]     = prev(db.end());
    nameMap[newPerson.name] = prev(db.end());
    ageMultimap.emplace(newPerson.age, prev(db.end()));

    showList(db, "Person Database (After insert)");
    showIndices(idMap, nameMap, ageMultimap);

    // --- Delete ---
    Person targetPerson("200", "Otto Mann", "45", "data200");
    cout << "\nRemoving ==> " << targetPerson << endl;

    auto dbit = find_if(db.begin(), db.end(),
        [&targetPerson](const Person& p) { return p.id == targetPerson.id; });

    if (dbit == db.end())
        throw runtime_error("Delete ignored - Record not found");

    // Step 1: erase from all indexes BEFORE erasing from the list
    idMap.erase(dbit->id);
    nameMap.erase(dbit->name);

    auto range = ageMultimap.equal_range(dbit->age);
    for (auto ait = range.first; ait != range.second; ++ait) {
        if (ait->second == dbit) { ageMultimap.erase(ait); break; }
    }

    // Step 2: erase from primary list
    db.erase(dbit);
    cout << "Deleted: " << targetPerson << endl;

    showList(db, "Person Database (After delete)");
    showIndices(idMap, nameMap, ageMultimap);
}

// TODO Part 3 ------------------------------------------------------------------
// Implement experiment03() — update an existing record.
// Requirements:
//   1. Load the database.
//   2. Prompt the user for an ID to update.
//   3. If not found, throw runtime_error.
//   4. Prompt for which field to update: name, age, or info.
//   5. Apply the update to the list node and refresh the affected index.
//   6. Call showList() and showIndices() to verify.
//
void experiment03() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database (Before update)");

    // TODO: prompt for ID
    // TODO: find record using idMap
    // TODO: prompt for field to update (name / age / info)
    // TODO: erase old index entry if name or age is changing
    // TODO: write new value to list node
    // TODO: re-insert new key into the affected index
    // TODO: showList and showIndices to verify
}

// Main -------------------------------------------------------------------------
int main() {
    try {
        experiment01();
        // experiment02();
        // experiment03();
    }
    catch (const runtime_error& e) {
        cout << "\nError: " << e.what() << endl;
    }
    cout << "\nAll done!\n";
}
