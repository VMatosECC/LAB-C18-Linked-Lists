// S0142-People-Database-SOLUTION.cpp
// CS2 Lab — Memory-Resident Database  (INSTRUCTOR SOLUTION)
//
// Dataset: https://github.com/VMatosECC/Datasets/tree/main/Simpsons
// Download springfieldpeople.txt ==> c:/temp/springfieldpeople.txt

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <list>
#include <map>
#include <algorithm>    // find_if
#include "Person.h"
using namespace std;

// Shorthand type aliases -------------------------------------------------------
typedef map<string, list<Person>::iterator>      DBmap;
typedef multimap<string, list<Person>::iterator> DBmmap;

// Utility functions ------------------------------------------------------------
template <class T>
void showList(const list<T>& lst, string caption = "") {
    cout << endl << caption << "  Size: " << lst.size() << endl;
    cout << string(50, '-') << endl;
    for (const auto& node : lst)
        cout << node << endl;
    cout << string(50, '-') << endl;
}

void showIndices(const DBmap& idMap,
    const DBmap& nameMap,
    const DBmmap& ageMultimap) {
    cout << "\nidMap (ID key ==> record)\n";
    for (const auto& row : idMap)
        cout << "  " << row.first << "\t" << *row.second << endl;

    cout << "\nnameMap (NAME key ==> record)\n";
    for (const auto& row : nameMap)
        cout << "  " << row.first << "\t" << *row.second << endl;

    cout << "\nageMultimap (AGE key ==> record(s))\n";
    for (const auto& row : ageMultimap)
        cout << "  " << row.first << "\t" << *row.second << endl;
}

// Load -------------------------------------------------------------------------
void loadDatabase(list<Person>& db,
    DBmap& idMap, DBmap& nameMap, DBmmap& ageMultimap) {
    ifstream infile("c:/temp/springfieldpeople.txt");
    if (!infile) { cout << "Fatal error - file not found\n"; exit(101); }

    Person p;
    while (getline(infile, p.id, ',') &&
        getline(infile, p.name, ',') &&
        getline(infile, p.age, ',') &&
        getline(infile, p.info)) {
        db.push_back(p);
        idMap[p.id] = prev(db.end());
        nameMap[p.name] = prev(db.end());
        ageMultimap.emplace(p.age, prev(db.end()));
    }
    infile.close();
}

// Search functions -------------------------------------------------------------
void exactSearch(const DBmap& m, string keyName = "") {
    string key;
    cout << "\n=== Exact search by " << keyName << " ===\n";
    do {
        cout << "(" << keyName << ") Enter search key [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto itm = m.find(key);
        if (itm == m.end())
            cout << "  Not found: \"" << key << "\"\n";
        else
            cout << "  Found ==> " << *itm->second << "\n";
    } while (true);
}

void multiSearch(const DBmmap& mm, string keyName = "") {
    string key;
    cout << "\n=== Exact search by " << keyName << " (multimap) ===\n";
    do {
        cout << "(" << keyName << ") Enter search key [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto range = mm.equal_range(key);
        if (range.first == range.second)
            cout << "  No records with " << keyName << " = " << key << "\n";
        else
            for (auto it = range.first; it != range.second; ++it)
                cout << "  Found ==> " << *it->second << "\n";
    } while (true);
}

void partialMatch(const DBmap& m, string keyName = "") {
    string key;
    cout << "\n=== Prefix search by " << keyName << " ===\n";
    do {
        cout << "(" << keyName << ") Enter prefix [q to end]: ";
        getline(cin, key);
        if (key == "q") break;
        auto it = m.lower_bound(key);
        bool found = false;
        while (it != m.end() && it->first.compare(0, key.size(), key) == 0) {
            cout << "  Found ==> " << *it->second << "\n";
            ++it;
            found = true;
        }
        if (!found) cout << "  No records with prefix \"" << key << "\"\n";
    } while (true);
}

// Part 4 Challenge Solution ----------------------------------------------------
// Prefix search on the age multimap.
// lower_bound and compare work identically on std::multimap as on std::map
// because the container is still sorted by key.
void partialMatchMulti(const DBmmap& mm, string keyName = "") {
    string prefix;
    cout << "\n=== Prefix search by " << keyName << " (multimap) ===\n";
    do {
        cout << "(" << keyName << ") Enter prefix [q to end]: ";
        getline(cin, prefix);
        if (prefix == "q") break;

        auto it = mm.lower_bound(prefix);
        bool found = false;
        while (it != mm.end() &&
            it->first.compare(0, prefix.size(), prefix) == 0) {
            cout << "  Found ==> " << *it->second << "\n";
            ++it;
            found = true;
        }
        if (!found)
            cout << "  No records with " << keyName
            << " prefix \"" << prefix << "\"\n";
    } while (true);
}

// Experiments ------------------------------------------------------------------
void experiment01() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database");
    showIndices(idMap, nameMap, ageMultimap);

    exactSearch(idMap, "ID");
    exactSearch(nameMap, "NAME");
    multiSearch(ageMultimap, "AGE");
    partialMatch(nameMap, "NAME PREFIX");
    partialMatchMulti(ageMultimap, "AGE PREFIX");
}

void experiment02() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database (Before insert)");

    // --- Insert ---
    Person newPerson("200", "Otto Mann", "45", "data200");
    cout << "\nAdding ==> " << newPerson << endl;

    if (idMap.count("200") == 1)
        throw runtime_error("Insert ignored - similar key already exists");

    db.push_back(newPerson);
    idMap[newPerson.id] = prev(db.end());
    nameMap[newPerson.name] = prev(db.end());
    ageMultimap.emplace(newPerson.age, prev(db.end()));

    showList(db, "Person Database (After insert)");
    showIndices(idMap, nameMap, ageMultimap);

    // --- Delete ---
    Person targetPerson("200", "Otto Mann", "45", "data200");
    cout << "\nRemoving ==> " << targetPerson << endl;

    auto dbit = find_if(db.begin(), db.end(),
        [&targetPerson](const Person& p) { return p.id == targetPerson.id; });

    if (dbit == db.end())
        throw runtime_error("Delete ignored - Record not found");

    // Step 1: erase from all indexes BEFORE erasing from the list
    idMap.erase(dbit->id);
    nameMap.erase(dbit->name);

    auto range = ageMultimap.equal_range(dbit->age);
    for (auto ait = range.first; ait != range.second; ++ait) {
        if (ait->second == dbit) { ageMultimap.erase(ait); break; }
    }

    // Step 2: erase from primary list
    db.erase(dbit);
    cout << "Deleted: " << targetPerson << endl;

    showList(db, "Person Database (After delete)");
    showIndices(idMap, nameMap, ageMultimap);
}

// Part 3 Solution --------------------------------------------------------------
// Update an existing record and keep all three indexes consistent.
//
// Strategy:
//   - ID is the primary key and never changes.
//   - If name or age changes, the old index entry must be erased and a new
//     one inserted. The list iterator (dbit) stays valid throughout.
//   - If only info changes, no index update is needed.
void experiment03() {
    list<Person> db;
    DBmap  idMap, nameMap;
    DBmmap ageMultimap;

    loadDatabase(db, idMap, nameMap, ageMultimap);
    showList(db, "Person Database (Before update)");

    // 1. Prompt for the ID to update
    string targetId;
    cout << "\nEnter ID to update [q to cancel]: ";
    getline(cin, targetId);
    if (targetId == "q") return;

    // 2. Find record using idMap (O(log n))
    auto idIt = idMap.find(targetId);
    if (idIt == idMap.end())
        throw runtime_error("Update ignored - ID not found: " + targetId);

    auto dbit = idIt->second;   // iterator into the list
    cout << "Record found ==> " << *dbit << endl;

    // 3. Prompt for which field to update
    cout << "\nWhich field to update? (name / age / info): ";
    string field;
    getline(cin, field);

    cout << "Enter new value: ";
    string newValue;
    getline(cin, newValue);

    // 4. Apply update and refresh affected index
    if (field == "name") {
        // Erase old nameMap entry, write new name, re-insert
        nameMap.erase(dbit->name);
        dbit->name = newValue;
        nameMap[dbit->name] = dbit;
    }
    else if (field == "age") {
        // Erase only this node's ageMultimap entry, write new age, re-insert
        auto range = ageMultimap.equal_range(dbit->age);
        for (auto ait = range.first; ait != range.second; ++ait) {
            if (ait->second == dbit) { ageMultimap.erase(ait); break; }
        }
        dbit->age = newValue;
        ageMultimap.emplace(dbit->age, dbit);
    }
    else if (field == "info") {
        // info is not an index key — update in place, no index change needed
        dbit->info = newValue;
    }
    else {
        cout << "Unknown field \"" << field << "\" — no changes made.\n";
        return;
    }

    cout << "Updated record ==> " << *dbit << endl;

    // 5. Verify
    showList(db, "Person Database (After update)");
    showIndices(idMap, nameMap, ageMultimap);
}

// Main -------------------------------------------------------------------------
int main() {
    try {
        experiment01();
        // experiment02();
        // experiment03();
    }
    catch (const runtime_error& e) {
        cout << "\nError: " << e.what() << endl;
    }
    cout << "\nAll done!\n";
}
